from flask import Flask, render_template, request, send_from_directory
import cv2
import numpy as np
from PIL import Image
import os
import uuid
import pandas as pd

app = Flask(__name__)

# Folders
UPLOAD_FOLDER = 'uploads'
RESULT_FOLDER = 'results'
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
os.makedirs(RESULT_FOLDER, exist_ok=True)

app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
app.config['RESULT_FOLDER'] = RESULT_FOLDER

# Allowed image extensions
ALLOWED_IMAGE_EXTENSIONS = {'png', 'jpg', 'jpeg'}

# Helper: check if file is image
def allowed_image(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_IMAGE_EXTENSIONS

# Home page
@app.route('/')
def index():
    return render_template('index.html')

# Serve processed images
@app.route('/results/<filename>')
def send_result(filename):
    return send_from_directory(app.config['RESULT_FOLDER'], filename)

# Preprocess image: enhance, straighten
def preprocess_image(image_path):
    img = Image.open(image_path).convert('RGB')
    img = np.array(img)
    img = cv2.cvtColor(img, cv2.COLOR_RGB2BGR)

    # Enhance contrast
    lab = cv2.cvtColor(img, cv2.COLOR_BGR2LAB)
    l, a, b = cv2.split(lab)
    clahe = cv2.createCLAHE(clipLimit=3.0, tileGridSize=(8,8))
    cl = clahe.apply(l)
    lab = cv2.merge((cl, a, b))
    img = cv2.cvtColor(lab, cv2.COLOR_LAB2BGR)

    # Sharpen
    blur = cv2.GaussianBlur(img, (0,0), 3)
    img = cv2.addWeighted(img, 1.5, blur, -0.5, 0)

    # Deskew
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    _, thresh = cv2.threshold(gray, 150, 255, cv2.THRESH_BINARY_INV)
    coords = np.column_stack(np.where(thresh > 0))
    if len(coords) > 0:
        angle = cv2.minAreaRect(coords)[-1]
        if angle < -45:
            angle = -(90 + angle)
        else:
            angle = -angle
        (h, w) = img.shape[:2]
        M = cv2.getRotationMatrix2D((w//2, h//2), angle, 1.0)
        img = cv2.warpAffine(img, M, (w, h), flags=cv2.INTER_CUBIC, borderMode=cv2.BORDER_REPLICATE)
    return img

# Detect only filled circular bubbles
def detect_bubbles(image_path):
    img = preprocess_image(image_path)
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    thresh = cv2.adaptiveThreshold(gray, 255, cv2.ADAPTIVE_THRESH_MEAN_C,
                                   cv2.THRESH_BINARY_INV, 15, 8)
    contours_data = cv2.findContours(thresh, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    contours = contours_data[0] if len(contours_data) == 2 else contours_data[1]

    detected = []
    for cnt in contours:
        area = cv2.contourArea(cnt)
        if 50 < area < 1500:
            (x_c, y_c), radius = cv2.minEnclosingCircle(cnt)
            circle_area = np.pi * (radius**2)
            if area / circle_area < 0.7:
                continue
            x, y, w, h = cv2.boundingRect(cnt)
            roi = thresh[y:y+h, x:x+w]
            fill_ratio = cv2.countNonZero(roi) / (w*h)
            if fill_ratio > 0.5:
                detected.append((int(x_c), int(y_c)))
                mask = np.zeros_like(roi)
                mask[roi>0] = 255
                colored_roi = img[y:y+h, x:x+w]
                colored_roi[mask==255] = [0, 255, 0]
                img[y:y+h, x:x+w] = colored_roi
    return detected, img

# Map bubbles to options (A-D cycle placeholder)
def map_bubbles(detected):
    detected_sorted = sorted(detected, key=lambda b: (b[1], b[0]))
    answers = []
    for idx, bubble in enumerate(detected_sorted):
        answers.append(chr(65 + (idx % 4)))  # A-D cycle
    return answers

# Upload route
@app.route('/upload', methods=['POST'])
def upload_file():
    if 'omr_file' not in request.files or 'answer_key' not in request.files:
        return "Please upload both OMR sheet and answer key."

    omr_file = request.files['omr_file']
    answer_key_file = request.files['answer_key']

    if omr_file.filename == '' or answer_key_file.filename == '':
        return "No file selected."

    # Save OMR sheet
    omr_filename = str(uuid.uuid4()) + os.path.splitext(omr_file.filename)[1]
    omr_path = os.path.join(app.config['UPLOAD_FOLDER'], omr_filename)
    omr_file.save(omr_path)

    # Save answer key (any format)
    key_filename = str(uuid.uuid4()) + os.path.splitext(answer_key_file.filename)[1]
    key_path = os.path.join(app.config['UPLOAD_FOLDER'], key_filename)
    answer_key_file.save(key_path)

    if not allowed_image(omr_file.filename):
        return "OMR sheet must be an image (PNG, JPG, JPEG)."

    # Detect bubbles in OMR sheet ONLY
    detected_omr, processed_omr = detect_bubbles(omr_path)
    if len(detected_omr) == 0:
        return "No bubbles detected on OMR sheet."

    omr_answers = map_bubbles(detected_omr)

    # Read answer key
    try:
        # If Excel
        if key_filename.lower().endswith(('.xls', '.xlsx')):
            df = pd.read_excel(key_path)
            key_answers = [str(a).upper() for a in df['Answer'].tolist()]
        else:
            # If TXT/CSV
            with open(key_path, 'r') as f:
                key_answers = [line.strip().upper() for line in f.readlines()]
    except:
        # Dummy key if reading fails
        key_answers = ['A'] * len(omr_answers)

    total_questions = min(len(omr_answers), len(key_answers))
    correct_count = sum([1 for i in range(total_questions) if omr_answers[i]==key_answers[i]])
    score = 0 if total_questions == 0 else round((correct_count/total_questions)*100, 2)

    # Feedback
    feedback = []
    for i in range(total_questions):
        status = "Correct" if omr_answers[i]==key_answers[i] else "Wrong"
        feedback.append((i+1, status, key_answers[i]))

    # Save processed image
    result_filename = "processed_" + omr_filename
    result_path = os.path.join(app.config['RESULT_FOLDER'], result_filename)
    cv2.imwrite(result_path, processed_omr)

    return render_template('result.html',
                           bubble_count=len(omr_answers),
                           total_questions=total_questions,
                           score=score,
                           feedback=feedback,
                           anomaly="",
                           result_file=result_filename)

if __name__ == '__main__':
    app.run(debug=True)
